/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author acer
 */
import controller.EmployeeController;
import model.Employee;
import validator.Input;
import validator.Validator;
import view.View;
import java.util.ArrayList;
import java.util.Scanner;

public class Main { 
    private final EmployeeController ec = new EmployeeController(); 
    private final Scanner sc = new Scanner(System.in); 
    private final View view = new View(sc); 
    private final Input input = new Input(sc);
    private boolean isDataChanged = false; 

    public static void main(String[] args) {
        Main program = new Main();
        program.run();
    }

    public void run() {
        while (true) { 
            int choice = view.showMainMenu();
            switch (choice) {
                case 1:
                    System.out.println("\n========== LOAD DATA ==========");
                    ec.reloadData();
                    view.showMessage("Load data successfully.");
                    break;
                case 2:
                    addEmployee();
                    break;
                case 3:
                    updateEmployee();
                    break;
                case 4:
                    removeEmployee();
                    break;
                case 5:
                    searchMenu();
                    break;
                case 6:
                    calculatePayroll();
                    break;
                case 7:
                    displayEmployees();
                    break;
                case 8:
                    System.out.println("\n========== SAVE DATA ==========");
                    if (ec.saveToFile()) {
                        isDataChanged = false; 
                        view.showMessage("Save successfully.");
                    } else {
                        view.showMessage("Save failed.");
                    }
                    break;
                case 9:
                    System.out.println("\n========== EXIT PROGRAM ==========");
                    if (isDataChanged) {
                        System.out.print("You have unsaved changes. Save before exit (Y/N): ");
                        String ans = sc.nextLine().trim();
                        if (ans.equalsIgnoreCase("Y")) {
                            ec.saveToFile();
                        }
                    }
                    System.out.println("Goodbye!");
                    sc.close();
                    return;
                default:
                    System.out.println("Please choose from 1-9.");
            }
        } 
    }

    
    public void addEmployee() {
        System.out.println("\n========== ADD NEW EMPLOYEE ==========");
        String id; 
        while (true) {
            id = input.inputString("Enter employee ID (Format Exxx): ").toUpperCase(); 
            if (!Validator.validEmployeeId(id)) {
                System.out.println("Invalid ID format."); 
                continue; 
            } 
            if (ec.findById(id) != null) {
                System.out.println("ID already exists."); 
                continue; 
            } 
            break; 
        } 

        String name; 
        while (true) {
            name = input.inputString("Enter employee name: "); 
            if (Validator.validName(name)) break; 
            System.out.println("Invalid name."); 
        } 

        String role;
        while (true) {
            role = input.inputString("Enter role (Developer, Tester, Manager, HR): "); 
            if (Validator.validRole(role)) break; 
            System.out.println("Invalid role."); 
        } 

        double salary = input.inputDouble("Enter base salary: ", 1); 
        int days = input.inputInt("Enter working days (0-26): ", 0, 26); 
        double bonus = input.inputDouble("Enter bonus: ", 0); 

        String status; 
        while (true) { 
            status = input.inputString("Enter status (active, inactive): ").toLowerCase(); 
            if (Validator.validStatus(status)) break; 
            System.out.println("Invalid status."); 
        } 

        ec.addEmployee(new Employee(id, name, role, salary, days, bonus, status)); 
        isDataChanged = true; 
        view.showMessage("Employee added successfully."); 
    }

    public void updateEmployee() {
        System.out.println("\n========== UPDATE EMPLOYEE ==========");
        String id = input.inputString("Enter employee ID to update: "); 
        Employee e = ec.findById(id); 
        if (e == null) {
            view.showMessage("Employee not found.");
            return; 
        } 

        System.out.println("Current information: " + e); 
        System.out.println("(Leave blank and press Enter to keep current values)");

        while (true) {
            System.out.print("New role (Current: " + e.getRole() + "): ");
            String role = sc.nextLine().trim();
            if (role.isEmpty()) break;
            if (Validator.validRole(role)) {
                e.setRole(role);
                break;
            }
            System.out.println("Invalid role."); 
        } 

        System.out.print("New salary (Current: " + e.getBaseSalary() + "): ");
        String salaryStr = sc.nextLine().trim();
        if (!salaryStr.isEmpty()) {
            try {
                double salary = Double.parseDouble(salaryStr);
                if (salary >= 1) e.setBaseSalary(salary);
                else System.out.println("Salary must be >= 1.");
            } catch (NumberFormatException ex) {
                System.out.println("Invalid number format.");
            }
        }

        System.out.print("New working days (Current: " + e.getWorkingDays() + "): ");
        String daysStr = sc.nextLine().trim();
        if (!daysStr.isEmpty()) {
            try {
                int days = Integer.parseInt(daysStr);
                if (Validator.isValidWorkingDays(days)) e.setWorkingDays(days);
                else System.out.println("Working days must be 0-26.");
            } catch (NumberFormatException ex) {
                System.out.println("Invalid integer format.");
            }
        }

        System.out.print("New bonus (Current: " + e.getBonus() + "): ");
        String bonusStr = sc.nextLine().trim();
        if (!bonusStr.isEmpty()) {
            try {
                double bonus = Double.parseDouble(bonusStr);
                if (Validator.isValidBonus(bonus)) e.setBonus(bonus);
                else System.out.println("Bonus must be >= 0.");
            } catch (NumberFormatException ex) {
                System.out.println("Invalid number format.");
            }
        }

        while (true) {
            System.out.print("New status (Current: " + e.getStatus() + "): ");
            String status = sc.nextLine().trim().toLowerCase();
            if (status.isEmpty()) break;
            if (Validator.validStatus(status)) {
                e.setStatus(status);
                break;
            }
            System.out.println("Invalid status."); 
        } 

        isDataChanged = true; 
        view.showMessage("Update successfully on RAM."); 
    }

    public void removeEmployee() {
        System.out.println("\n========== REMOVE EMPLOYEE ==========");
        String id = input.inputString("Enter employee ID to remove: "); 
        if (ec.removeEmployee(id)) {
            isDataChanged = true; 
            view.showMessage("Employee removed successfully."); 
        } else {
            view.showMessage("Employee not found.");
        }
    }

    public void searchMenu() {
        System.out.println("\n========== SEARCH EMPLOYEE ==========");
        System.out.println("1. Search by ID"); 
        System.out.println("2. Search by Name"); 
        System.out.println("3. Search by Role"); 
        System.out.println("4. Search by Status"); 
        int choice = input.inputInt("Choose (1-4): ", 1, 4); 
        switch (choice) { 
            case 1: 
                String id = input.inputString("Enter ID: "); 
                Employee e = ec.findById(id); 
                if (e == null) {
                    view.showMessage("Employee not found."); 
                } else {
                    view.printHeader(); 
                    view.printEmployee(e); 
                }
                break; 
            case 2: 
                String name = input.inputString("Enter name keyword: "); 
                view.showEmployeeList((ArrayList<Employee>) ec.searchByName(name)); 
                break;
            case 3: 
                String role = input.inputString("Enter role: "); 
                view.showEmployeeList((ArrayList<Employee>) ec.searchByRole(role)); 
                break; 
            case 4: 
                String status = input.inputString("Enter status: "); 
                view.showEmployeeList((ArrayList<Employee>) ec.searchByStatus(status)); 
                break; 
        } 
    }

    public void calculatePayroll() {
        System.out.println("\n========== MONTHLY PAYROLL ==========");
        System.out.println("--------------------------------------------------------");
        System.out.printf("%-8s | %-25s | %-15s\n", "ID", "NAME", "TOTAL SALARY");
        System.out.println("--------------------------------------------------------");
        for (Employee e : ec.getList()) {
            if (e.getStatus().equalsIgnoreCase("active")) {
                System.out.printf("%-8s | %-25s | %-15.2f\n", e.getId(), e.getName(), e.calculateTotalSalary());
            }
        }
        System.out.println("--------------------------------------------------------");
    }

    public void displayEmployees() {
        System.out.println("\n========== EMPLOYEE LIST ==========");
        view.showEmployeeList(ec.getList()); 
    }
}
