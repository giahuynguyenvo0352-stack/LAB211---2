/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author acer
 */
public class Employee {
    private String id;
    private String name;
    private String role;
    private double baseSalary;
    private int workingDays;
    private double bonus;
    private String status;

    public Employee() {
    }

    public Employee(String id, String name, String role, double baseSalary, int workingDays, double bonus, String status) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.baseSalary = baseSalary;
        this.workingDays = workingDays;
        this.bonus = bonus;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }

    public int getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(int workingDays) {
        this.workingDays = workingDays;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public double calculateTotalSalary() {
        if ("active".equalsIgnoreCase(this.status)) {
            return this.baseSalary + (this.workingDays * 50) + this.bonus;
        }
        return 0;
    }

    @Override
    public String toString() {
        return String.format("%s, %s, %s, %.1f, %d, %.1f, %s", 
                id, name, role, baseSalary, workingDays, bonus, status);
    }
    
    
}
