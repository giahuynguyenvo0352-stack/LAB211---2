/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validator;

/**
 *
 * @author acer
 */
import java.util.Scanner;

public class Input {
    private final Scanner sc;

    public Input(Scanner sc) {
        this.sc = sc;
    }

    public String inputString(String msg) {
        while (true) {
            System.out.print(msg);
            String str = sc.nextLine().trim();
            if (!str.isEmpty()) return str;
            System.out.println("Error: Input cannot be empty!");
        }
    }

    public int inputInt(String msg, int min, int max) {
        while (true) {
            try {
                System.out.print(msg);
                int num = Integer.parseInt(sc.nextLine().trim());
                if (num >= min && num <= max) return num;
                System.out.printf("Error: Number must be in range [%d - %d]\n", min, max);
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a valid integer number!");
            }
        }
    }

    public double inputDouble(String msg, double min) {
        while (true) {
            try {
                System.out.print(msg);
                double num = Double.parseDouble(sc.nextLine().trim());
                if (num >= min) return num;
                System.out.printf("Error: Value must be >= %.0f\n", min);
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a valid decimal number!");
            }
        }
    }
}
