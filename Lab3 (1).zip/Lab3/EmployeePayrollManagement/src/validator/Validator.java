/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validator;
/**
 *
 * @author acer
 */
import java.util.Arrays;
public class Validator {
    private static final String EID_PATTERN = "^E\\d{3}$";
    private static final String NAME_PATTERN = "^[A-Za-z]{2,20}$";
    private static final String[] ROLE = {"Developer", "Tester", "Manager", "HR"};
    private static final String[] STATUS = {"active", "inactive"};
    
    public static boolean validEmployeeId(String id) {
        return id != null && id.matches(EID_PATTERN);
    }
    
    public static boolean validName(String name) {
        return name != null && name.matches(NAME_PATTERN);
    }
    
    public static boolean validRole(String role){
        return role != null && Arrays.asList(ROLE).contains(role);
    }
    public static boolean validStatus(String status){
        return status != null && Arrays.asList(STATUS).contains(status);
    }
    
    public static boolean isValidWorkingDays(int days) {
        return days >= 0 && days <= 26;
    }

    public static boolean isValidBonus(double bonus) {
        return bonus >= 0;
    }
}
