/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utilio;

/**
 *
 * @author acer
 */
import java.io.*;
import java.util.ArrayList;
import model.Employee;
import validator.Validator;

public class EmployeeFileHelper implements WriteReadFile {

    @Override
    public ArrayList<Employee> read(String path) throws Exception {
        ArrayList<Employee> list = new ArrayList<>();
        File f = new File(path);
        if (!f.exists()) {
            return list;
        }
        
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    if (line.trim().isEmpty()) {
                        continue;
                    }
                    String[] p = line.split(",");

                    if (p.length != 7) {
                        continue;
                    }
                    
                    String id = p[0].trim();
                    String name = p[1].trim();
                    String role = p[2].trim();
                    double salary = Double.parseDouble(p[3].trim());
                    int days = Integer.parseInt(p[4].trim());
                    double bonus = Double.parseDouble(p[5].trim());
                    String status = p[6].trim().toLowerCase();
                    if (Validator.validEmployeeId(id) && Validator.validName(name) 
                            && Validator.validRole(role) && Validator.validStatus(status)
                            && Validator.isValidWorkingDays(days) && Validator.isValidBonus(bonus)) {
                        
                        list.add(new Employee(id, name, role, salary, days, bonus, status));
                    }
                } catch (NumberFormatException ex) {
                }
            }
        }
        return list;
    }

    @Override
    public void write(String path, ArrayList<Employee> list) throws Exception {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (Employee e : list) {
                bw.write(e.getId() + ","
                        + e.getName() + ","
                        + e.getRole() + ","
                        + e.getBaseSalary() + ","
                        + e.getWorkingDays() + ","
                        + e.getBonus() + ","
                        + e.getStatus());
                bw.newLine();
            }
        }
    }
}
