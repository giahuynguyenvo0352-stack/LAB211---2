/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package utilio;

/**
 *
 * @author acer
 */
import java.util.ArrayList;
import model.Employee;

public interface WriteReadFile {
    ArrayList<Employee> read(String path) throws Exception;
    void write(String path, ArrayList<Employee> list) throws Exception;
}
