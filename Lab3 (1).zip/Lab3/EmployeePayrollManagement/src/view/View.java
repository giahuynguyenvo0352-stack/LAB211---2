/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author acer
 */
import java.util.ArrayList;
import model.Employee;
import java.util.Scanner;
public class View {
    Scanner sc = new Scanner(System.in);
    
    public View(Scanner sc) {
    this.sc = sc;
}
    
    public int showMainMenu() {
    System.out.println("\n===== EMPLOYEE PAYROLL MANAGEMENT =====");

    String[] options = {
        "Load employee data from file",
        "Add a new employee",
        "Update employee information",
        "Remove employee by ID",
        "Search employees by attribute",
        "Calculate monthly payroll",
        "Display employee list",
        "Save data to file",
        "Quit"
    };

    Menu.showMenu(options);

    while (true) {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.print("Invalid choice! Enter again: ");
        }
    }
}

    public void showMessage(String msg) {
        System.out.println(msg);
    }

    public void printHeader() {
    System.out.println("------------------------------------------------------------------------------------------");
    System.out.printf( "%-5s | %-20s | %-10s | %-10s | %-3s | %-10s | %-8s\n",
                "ID",
                "Name",
                "Role",
                "Salary",
                "Day",
                "Bonus",
                "Status");
    System.out.println("------------------------------------------------------------------------------------------");
    }

    public void printEmployee(Employee e) {
    System.out.printf(
            "%-5s | %-20s | %-10s | %-10.1f | %-3d | %-10.1f | %-8s\n",
            e.getId(),
            e.getName(),
            e.getRole(),
            e.getBaseSalary(),
            e.getWorkingDays(),
            e.getBonus(),
            e.getStatus()
    );
}

    public void showEmployeeList(ArrayList<Employee> list) {
        if (list.isEmpty()) {
            System.out.println("No employee found.");
            return;
        }
        printHeader();
        for (Employee e : list) {
            printEmployee(e);
        }
    }
}
