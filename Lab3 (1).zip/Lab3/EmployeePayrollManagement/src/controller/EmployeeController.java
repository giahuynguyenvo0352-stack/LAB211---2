/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author acer
 */
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import model.Employee;
import utilio.EmployeeFileHelper;
import utilio.WriteReadFile;

public class EmployeeController { 
    private ArrayList<Employee> employees; 
    private final String FILE_NAME = "employees.txt"; 
    private final String REPORT_FILE = "EmployeeReport.csv"; 
    
    public EmployeeController() { 
        reloadData();
    } 
    
    public ArrayList<Employee> getList() { 
        return employees; 
    } 
    
    public Employee findById(String id) { 
        for (Employee e : employees) { 
            if (e.getId().equalsIgnoreCase(id.trim())) { 
                return e; 
            } 
        } 
        return null; 
    } 

    public void addEmployee(Employee e) {
        employees.add(e);
    }

    public boolean removeEmployee(String id) {
        Employee e = findById(id);
        if (e != null) {
            employees.remove(e);
            return true;
        }
        return false;
    }

    public List<Employee> searchByName(String name) {
        List<Employee> result = new ArrayList<>();
        for (Employee e : employees) {
            if (e.getName().toLowerCase().contains(name.toLowerCase())) {
                result.add(e);
            }
        }
        return result;
    }

    public List<Employee> searchByRole(String role) {
        List<Employee> result = new ArrayList<>();
        for (Employee e : employees) {
            if (e.getRole().equalsIgnoreCase(role.trim())) {
                result.add(e);
            }
        }
        return result;
    }

    public List<Employee> searchByStatus(String status) {
        List<Employee> result = new ArrayList<>();
        for (Employee e : employees) {
            if (e.getStatus().equalsIgnoreCase(status.trim())) {
                result.add(e);
            }
        }
        return result;
    }
    
    public void reloadData() { 
        try { 
            WriteReadFile file = new EmployeeFileHelper(); 
            employees = file.read(FILE_NAME); 
        } catch (Exception e) { 
            employees = new ArrayList<>(); 
        } 
    } 
    
    public boolean saveToFile() {
        try {
            WriteReadFile file = new EmployeeFileHelper(); 
            file.write(FILE_NAME, employees); 
            exportToExcel();
            return true;
        } catch (Exception e) {
            return false;
        } 
    } 
    
    public void exportToExcel() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(REPORT_FILE))) {
            pw.println("ID,Name,Role,BaseSalary,WorkingDays,Bonus,Status,TotalSalary"); 
            for (Employee e : employees) {
                pw.println(e.getId() + "," + e.getName() + "," + e.getRole() + "," 
                        + e.getBaseSalary() + "," + e.getWorkingDays() + "," 
                        + e.getBonus() + "," + e.getStatus() + "," + e.calculateTotalSalary()); 
            } 
        } catch (Exception e) {
        } 
    } 
}
