    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author acer
 */
import java.io.Serializable;
import static view.Show.ROW_FORMAT;
public class Vehicle implements Serializable, Comparable<Vehicle> {
    private String VehicleID;
    private String VehicleName;
    private String VehicleColor;
    private double VehiclePrice;
    private String VehicleBrand;
    private static final long serialVersionUID = 1L;

    public String getVehicleBrand() {
        return VehicleBrand;
    }

    public void setVehicleBrand(String VehicleBrand) {
        this.VehicleBrand = VehicleBrand;
    }
    private String VehicleType;
    private int ProductYear;

    public Vehicle() {
    }

    public Vehicle(String VehicleID, String VehicleName, String VehicleColor, double VehiclePrice, String VehicleBrand, String VehicleType, int ProductYear) {
        this.VehicleID = VehicleID;
        this.VehicleName = VehicleName;
        this.VehicleColor = VehicleColor;
        this.VehiclePrice = VehiclePrice;
        this.VehicleBrand = VehicleBrand;
        this.VehicleType = VehicleType;
        this.ProductYear = ProductYear;
    }

    

    public String getVehicleID() {
        return VehicleID;
    }

    public void setVehicleID(String VehicleID) {
        this.VehicleID = VehicleID;
    }

    public String getVehicleName() {
        return VehicleName;
    }

    public void setVehicleName(String VehicleName) {
        this.VehicleName = VehicleName;
    }

    public String getVehicleColor() {
        return VehicleColor;
    }

    public void setVehicleColor(String VehicleColor) {
        this.VehicleColor = VehicleColor;
    }

    public double getVehiclePrice() {
        return VehiclePrice;
    }

    public void setVehiclePrice(double VehiclePrice) {
        this.VehiclePrice = VehiclePrice;
    }

    public String getVehicleType() {
        return VehicleType;
    }

    public void setVehicleType(String VehicleType) {
        this.VehicleType = VehicleType;
    }

    public int getProductYear() {
        return ProductYear;
    }

    public void setProductYear(int ProductYear) {
        this.ProductYear = ProductYear;
    }
    
    @Override
    public String toString() {
        return String.format(ROW_FORMAT, getVehicleID(), getVehicleName(), getVehicleColor(), getVehiclePrice(), getVehicleBrand(), getVehicleType(), getProductYear());
    }

    @Override
    public int compareTo(Vehicle other) {
        return Double.compare(this.VehiclePrice, other.VehiclePrice);
    }

    
    
}
