/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author acer
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.Year;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import model.Vehicle;
import validate.Inputter;
import validate.Validator;
import view.Show;

public class VehicleController   {
    ArrayList<Vehicle> Vehicles = new ArrayList<>();
    Inputter in;
    private static final String PATH_FILE = "vehicle.dat";

    public VehicleController(Inputter in) {
        this.in = in;
        loadFromFile();         
    }

    // Ham phu: tim xe theo id, KHONG hoi nhap
    private Vehicle findById(String id) {
        for (Vehicle v : Vehicles) {
            if (v.getVehicleID().equals(id)) {
                return v;
            }
        }
        return null;
    }

    // Ham phu cho update: nhap id moi, cho phep de trong, khong cho trung id
    private String inputNewId(String upId) {
        while (true) {
            String s = in.inputString("Nhap id moi (Enter de bo qua)",
                    Validator.ID_PATTERN + "|", "Id phai co dang V + 3 chu so");
            if (s.isEmpty() || s.equals(upId) || findById(s) == null) {
                return s;
            }
            System.out.println("Id da ton tai, nhap id khac");
        }
    }

    // Ham 1
    public void add(){
        String id, name, color, brand, type;
        double price;
        int productYear;
        while (true) {
            id = in.inputString("Nhap id cua xe (VD: V001)", Validator.ID_PATTERN,
                    "Id phai co dang V + 3 chu so");
            if (findById(id) == null) break;
            System.out.println("Id da ton tai, nhap id khac");
        }
        name = in.inputString("Nhap ten cua xe", Validator.NAME_PATTERN,
                "Ten 2-30 ky tu, gom chu, so, dau cach, '.' va '-'");
        color = in.inputString("Nhap mau cua xe", Validator.COLOR_PATTERN,
                "Mau 3-20 ky tu, chi gom chu cai va dau cach");
        price = in.inputDouble("Nhap gia cua xe", 0, 200);
        brand = in.inputString("Nhap thuong hieu xe " + Arrays.toString(Validator.BRANDS),
                Validator.BRAND_PATTERN, "Thuong hieu khong co trong danh sach");
        type = in.inputString("Nhap loai xe " + Arrays.toString(Validator.TYPES),
                Validator.TYPE_PATTERN, "Loai xe khong co trong danh sach");
        productYear = in.inputInt("Nhap nam san xuat", 1990, Year.now().getValue());
        Vehicle x = new Vehicle(id, name, color, price*100000000, brand, type, productYear);
        Vehicles.add(x);
        System.out.println("Them xe thanh cong");
    }
    // id, name, color,price,brand,type,productyear
    // Ham 2
    public void update() {
    String upId = in.inputString("Nhap id xe can update", Validator.ID_PATTERN,
            "Id phai co dang V + 3 chu so");
    Vehicle x = findById(upId);
    if (x == null) {
        System.out.println("Vehicle does not exist");
        return;
    }
    System.out.println("Thong tin nao khong can thay doi thi Enter de bo qua");

    String newId = inputNewId(upId);
    if (!newId.isEmpty()) x.setVehicleID(newId);

    String newName = in.inputString("Nhap ten moi (Enter de bo qua)",
            Validator.NAME_PATTERN + "|", "Ten 2-30 ky tu, gom chu, so, dau cach, '.' va '-'");
    if (!newName.isEmpty()) x.setVehicleName(newName);

    String newColor = in.inputString("Nhap mau moi (Enter de bo qua)",
            Validator.COLOR_PATTERN + "|", "Mau 3-20 ky tu, chi gom chu cai va dau cach");
    if (!newColor.isEmpty()) x.setVehicleColor(newColor);

    Double newPrice = in.inputDoubleOptional("Nhap gia moi (Enter de bo qua)", 0, 200);
    if (newPrice != null) x.setVehiclePrice(newPrice * 100000000);

    String newBrand = in.inputString("Nhap thuong hieu moi (Enter de bo qua) "
            + Arrays.toString(Validator.BRANDS),
            Validator.BRAND_PATTERN + "|", "Thuong hieu khong co trong danh sach");
    if (!newBrand.isEmpty()) x.setVehicleBrand(newBrand);

    String newType = in.inputString("Nhap kieu xe moi (Enter de bo qua) "
            + Arrays.toString(Validator.TYPES),
            Validator.TYPE_PATTERN + "|", "Loai xe khong co trong danh sach");
    if (!newType.isEmpty()) x.setVehicleType(newType);

    Integer newYear = in.inputIntOptional("Nhap nam san xuat moi (Enter de bo qua)",
            1990, Year.now().getValue());
    if (newYear != null) x.setProductYear(newYear);

    System.out.println("Cap nhat thanh cong");
}
    //Ham 3
    public boolean checkExist(String id){
    id = in.inputString("Nhap Id Can Kiem Tra", Validator.ID_PATTERN,
            "Id phai co dang V + 3 chu so");
    Vehicle v = findById(id);
    if (v != null) {
        System.out.println(v);   // in thông tin xe
        return true;
    }
    return false;
    }
    //Ham 4
    public void Delete(String id){
    id = in.inputString("Nhap Id Can Xoa", Validator.ID_PATTERN,
            "Id phai co dang V + 3 chu so");
    Vehicle v = findById(id);
    if (v == null) {
        System.out.println(id + " khong ton tai");
    } else {
        Vehicles.remove(v);
        System.out.println("Xoa thanh cong");
    }
    }
    //Ham 5
    public void ShowAll() {
        Show.showList(Vehicles);
    }
    //Ham 6
    public void SearchByName(String name){
        ArrayList<Vehicle> H =  new ArrayList<>();
        name = in.inputString("Enter car's name need to find", ".+", "No empty");
        for (Vehicle v : Vehicles){
            if (v.getVehicleName().contains(name)){
                H.add(v);
            }
        }
        H.sort((a, b) -> a.getVehicleName().compareToIgnoreCase(b.getVehicleName()));
        Show.showList(H);
    }
    //Ham 7
    public void SearchByID (String id){
        id = in.inputString("Nhap id xe can tim", Validator.ID_PATTERN,
                "Id phai co dang V + 3 chu so");
        for (Vehicle V : Vehicles){
            if(V.getVehicleID().equals(id)){
                System.out.println(V.toString());
                return;
            }
        }
    }
    //Ham 8
    public void ShowByPrice(double price) {
        ArrayList<Vehicle> TempVehicle = new ArrayList<>();
        price = in.inputDouble("Nhap so tien ban muon loc danh sach", 0, 200);
        double limit = price*100000000;
        for (Vehicle V : Vehicles){
            if (V.getVehiclePrice() < limit){
                TempVehicle.add(V);
            }
        }
        Collections.sort(TempVehicle, Collections.reverseOrder());
        Show.showList(TempVehicle);
    }

    //Ham 9
    public void saveToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(PATH_FILE))) {
            oos.writeObject(Vehicles);
            System.out.println("Luu file thanh cong (" + Vehicles.size() + " xe)");
        } catch (IOException e) {
            System.out.println("Luu file that bai: " + e.getMessage());
        }
    }
    //Ham 10
    @SuppressWarnings("unchecked")
    public void printFromFile(){
        File f = new File(PATH_FILE);
        if (!f.exists()) {
            System.out.println("Chua co file vehicle.dat, hay luu (chuc nang 9) truoc");
            return;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            ArrayList<Vehicle> list = (ArrayList<Vehicle>) ois.readObject();
            if (list.isEmpty()) {
                System.out.println("File khong co xe nao");
            } else {
                Show.showList(list);
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Doc file that bai: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadFromFile() {
    File f = new File(PATH_FILE);
    if (!f.exists()) return;
    try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
        Vehicles = (ArrayList<Vehicle>) ois.readObject();
    } catch (IOException | ClassNotFoundException e) {
        System.out.println("Doc file that bai: " + e.getMessage());
    }
}
}



