/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author acer
 */
import controller.VehicleController;
import java.util.Scanner;
import model.Vehicle;
import validate.Inputter;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Inputter in = new Inputter();
        VehicleController vc = new VehicleController(in);
        int choice = 0;
        do{
        System.out.println("Vehicles Management");
        //Menu list
        System.out.println("1. Add new vehicle");
        System.out.println("2. Check exist vehicle");
        System.out.println("3. Update vehicle");
        System.out.println("4. Delete vehicle");
        System.out.println("5. Search vehicle by ID");
        System.out.println("6. Search vehicle by Name");
        System.out.println("7. Display all vehicle");
        System.out.println("8. Show vehicle by price");
        System.out.println("9. Save to file");
        System.out.println("10. Print all vehicle from the file");
        System.out.println("11. Quit");
        choice = in.inputInt("Enter choice (1-11): ", 1, 11);
        switch(choice){
            case 1:
                System.out.println("-----------------------------Them Xe Moi------------------------------");
                vc.add();
                break;
            case 2: {
                System.out.println("-------------------------Kiểm Tra Xe Tồn Tại--------------------------");
                if (vc.checkExist("") != false) {
                    System.out.println("Existed Vehicle");
                } else {
                    System.out.println("No Vehicle Found!");
                }
                break;
            }
            case 3:
                System.out.println("------------------------Chỉnh Sửa Thông Tin Xe------------------------");
                vc.update();
                break;
            case 4:
                System.out.println("------------------------Xóa Xe Trong Danh Sách------------------------");
                vc.Delete("");
                break;
            case 5:
                System.out.println("----------------------------Tìm Xe Theo ID----------------------------");
                vc.SearchByID("");
                break;
            case 6:
                System.out.println("---------------------------Tìm Xe Theo Tên----------------------------");
                vc.SearchByName("");
                break;
            case 7:
                System.out.println("---------------------------Show Toàn Bộ Xe----------------------------");
                vc.ShowAll();
                break;
            case 8:
                System.out.println("---------------Hiển Thị Xe Có Giá Tiền Thấp Hơn Yêu Cầu---------------");
                vc.ShowByPrice(0);
                break;
            case 9:
                System.out.println("-----------------------------Lưu Vào File-----------------------------");
                vc.saveToFile();
                break;
            case 10:
                System.out.println("----------------------------In Ra Từ File-----------------------------");
                vc.printFromFile();
                break;
            case 11:
                System.out.println("Exit program successful");
                break;
        }
        } while (choice !=11);
    }
}
