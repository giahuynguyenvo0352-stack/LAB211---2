/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
/**
 *
 * @author acer
 */
import model.Vehicle;
import java.util.List;
public class Show {
    public static final String HEADER_FORMAT = "| %-5s | %-20s | %-15s | %-15s | %-10s | %-10s | %4s |";
    public static final String ROW_FORMAT   = "| %-5s | %-20s | %-15s | %15.2f | %-10s | %-10s | %4d |";
    public static final String HEADER = String.format(HEADER_FORMAT,"ID", "Name", "Color", "Price", "Brand", "Type", "Year");
    public static void showList(List<Vehicle> list){
        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println(String.format(HEADER_FORMAT,"ID", "Name", "Color", "Price", "Brand", "Type", "Year"));
        System.out.println("----------------------------------------------------------------------------------------------------------");
        for (Vehicle V : list){
            System.out.println(String.format(ROW_FORMAT, V.getVehicleID(), V.getVehicleName(), V.getVehicleColor(), V.getVehiclePrice(), V.getVehicleBrand(), V.getVehicleType(), V.getProductYear()));
        }
        System.out.println("----------------------------------------------------------------------------------------------------------");
    }
}
