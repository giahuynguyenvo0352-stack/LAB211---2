/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validate;

/**
 *
 * @author acer
 */
import java.time.Year;
public class Validator {
    public static final String ID_PATTERN = "V\\d{3}";
    public static final String NAME_PATTERN = "[\\p{L}0-9][\\p{L}0-9 .\\-]{1,29}";
    public static final String[] BRANDS = {"Toyota", "Honda", "Hyundai", "Kia",
        "Mazda", "Ford", "Mitsubishi", "Suzuki", "VinFast", "Yamaha", "SYM",
        "Piaggio", "Ducati", "Kawasaki", "BMW", "Mercedes-Benz"};
    public static final String[] TYPES = {"Car", "Motorbike", "Truck", "Bus",
        "Van", "Electric bike", "Bicycle"};
    public static final String COLOR_PATTERN = "\\p{L}[\\p{L} ]{2,19}";
    // BRANDS/TYPES phai khai bao TRUOC hai dong nay
    public static final String BRAND_PATTERN = "(?i)(" + String.join("|", BRANDS) + ")";
    public static final String TYPE_PATTERN  = "(?i)(" + String.join("|", TYPES) + ")";
    public static boolean validPrice(double price){
        return price >= 0 || price <=200; 
    }
    
    public static boolean validProductYear(int year){
        return year >= 1990 || year <= Year.now().getValue();
    }
    
}
