/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validate;

/**
 *
 * @author acer
 */
import java.util.Scanner;

public class Inputter {

    Scanner sc = new Scanner(System.in);

    public String inputString(String mess, String pattern, String error) {
        while (true) {
            System.out.println(mess); //in ra yeu cau
            String s = sc.nextLine().trim();
            if (s.matches(pattern)) {
                return s;
            } else {
                System.out.println(error);
            }
        }
    }
    
    public double inputDouble(String mess, double min, double max){
        while (true) {
            try {
            System.out.println(mess); //in ra yeu cau
            Double d = Double.parseDouble(sc.nextLine().trim());
            if (d >= min && d <= max) {
                return d;
            }
            } catch (NumberFormatException e){
                System.out.println("Phai nhap gia tri so thuc");
            }
        }        
    } 
    
        public int inputInt(String mess, int min, int max){
        while (true) {
            try {
            System.out.println(mess); //in ra yeu cau
            int i = Integer.parseInt(sc.nextLine().trim());
            if (i >= min && i <= max) {
                return i;
            }
            } catch (NumberFormatException e){
                System.out.println("Phai nhap gia tri so thuc");
            }
        }        
    } 
        
    public Double inputDoubleOptional(String mess, double min, double max) {
    while (true) {
        System.out.println(mess);
        String s = sc.nextLine().trim();
        if (s.isEmpty()) return null;
        try {
            double d = Double.parseDouble(s);
            if (d >= min && d <= max) return d;
            System.out.println("Gia tri phai tu " + min + " den " + max);
        } catch (NumberFormatException e) {
            System.out.println("Phai nhap gia tri so thuc");
        }
    }
}

    public Integer inputIntOptional(String mess, int min, int max) {
    while (true) {
        System.out.println(mess);
        String s = sc.nextLine().trim();
        if (s.isEmpty()) return null;
        try {
            int i = Integer.parseInt(s);
            if (i >= min && i <= max) return i;
            System.out.println("Gia tri phai tu " + min + " den " + max);
        } catch (NumberFormatException e) {
            System.out.println("Phai nhap so nguyen");
        }
    }
}
}